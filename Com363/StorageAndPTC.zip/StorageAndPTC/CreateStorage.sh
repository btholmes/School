eval "javac Demo/CreateStorageMain.java" 
eval "java Demo.CreateStorageMain"
read -rsp $'Press enter to continue...\n'


