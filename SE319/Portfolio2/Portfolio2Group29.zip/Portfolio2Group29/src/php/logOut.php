<?php
/**
 * Created by IntelliJ IDEA.
 * User: btholmes
 * Date: 11/10/16
 * Time: 5:11 AM
 */

session_destroy();
//$conn->close();