<?php
/**
 * Created by IntelliJ IDEA.
 * User: btholmes
 * Date: 11/11/16
 * Time: 12:31 AM
 */

$info = "[" . file_get_contents("images.txt") . "]";
echo $info;