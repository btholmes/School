myApp.constant("CONSTANTS", {
    "check_login_url" : "./php/checkLogin.php",
    "add_user_url" : "./php/storeLogin.php",
    "log_out_url" : "./php/logOut.php",
    "store_image_url" : "./php/storeImage.php",
    "get_images_url" : "./php/getImages.php"
});