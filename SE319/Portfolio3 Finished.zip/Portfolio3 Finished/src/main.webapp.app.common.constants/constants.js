angular.module('myApp').constant("CONSTANTS", {
    "REVERSE_GEOLOCATION_BEGINNING" : "https://maps.googleapis.com/maps/api/geocode/json?latlng=",
    "REVERSE_GEOLOCATION_ENDING" : "&key=AIzaSyAd1xMYT1bt99qtFWQEzXiRBvORDWHgPtk"
});