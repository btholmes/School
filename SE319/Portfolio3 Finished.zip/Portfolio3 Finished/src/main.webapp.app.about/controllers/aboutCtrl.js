(function() {
	'use strict';

	angular.module("myApp")
	.controller("aboutCtrl", aboutCtrl);
	
	
	function aboutCtrl() {
		var vm = this;
	}
})();