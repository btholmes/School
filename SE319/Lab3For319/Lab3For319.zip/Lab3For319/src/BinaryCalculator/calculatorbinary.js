var memory = "";

function twosCompliment(binaryval){
	var compliment = "";
	//Find compliment of binaryval.
	for(var i = 0; i < binaryval.length; i++){
		if(binaryval[i] == "1"){
			compliment += "0";
		}
		else{
			compliment += "1";
		}
	}
	//Add one to binaryval's compliment.
	var carry = 1;
	var twocompliment = "";
	for(i = compliment.length-1; i >= 0; i--){
		if(compliment[i] == "1" && carry == 1){
			twocompliment += "0";
			carry = 1;
		} 
		else if(compliment[i] == "0" && carry == 1){
			twocompliment += "1";
			carry = 0;
		}
		else{
			twocompliment += compliment[i];
		}
	}
//	if(carry == 1){
//		compliment += "1";
//	}	
	return reverse(twocompliment);
};

function reverse(s){
	return s.split('').reverse().join('');
};

function updateDisplay(symbol){
	document.getElementById("display").value += symbol;
};

function binarytodecimal(binary){
	var decimal = 0;
	
	for(var i = 0; i < binary.length; i++){
		decimal += parseFloat(binary[i]) * Math.pow(2, binary.length - 1 - i);
	}	
	return decimal;
};

function decimaltobinary(dec){	
    if(dec >= 0) {
        return dec.toString(2);
    }
    else {
        return (~dec).toString(2);
    }
};

function addone(){
	updateDisplay(1);
};

function addzero(){
	updateDisplay(0);
};

function tilde(){
	if(document.getElementById("display").value == " "){
		alert("the ~ must be the second element followed by =.");
	}
	else{
		updateDisplay(" ~ ");
	}
};

function add(){
//	lhsbinary = document.getElementById("display").value.trim();
	updateDisplay(" + ");
};

function lshift(){
//	lhsbinary = document.getElementById("display").value.trim();
	updateDisplay(" << ");
};

function rshift(){
//	lhsbinary = document.getElementById("display").value.trim();
	updateDisplay(" >> ");
};

function subtract(){
//	lhsbinary = document.getElementById("display").value.trim();
	updateDisplay(" - ");
};

function and(){
//	lhsbinary = document.getElementById("display").value.trim();
	updateDisplay(" & ");
};

function or(){
//	lhsbinary = document.getElementById("display").value.trim();
	updateDisplay(" | ");
};

function multiply(){
//	lhsbinary = document.getElementById("display").value.trim();
	updateDisplay(" * ");
};

function divide(){
//	lhsbinary = document.getElementById("display").value.trim();
	updateDisplay(" / ");
};

function showmem(){
	document.getElementById("display").innerHTML = memory;
	updateDisplay(memory);
};

function subtractmem(){
	var largeststring = 0;
	var rhs = document.getElementById("display").value;
	// Check to see if rhs and lhs are the same length.
	// If not, pad the shorter side with zeros in front.
	if(memory.length < rhs.length){
		largeststring = rhs.length;
		var difference = rhs.length - memory.length;
		var temp = "";
		for(var i = 0; i < difference; i++){
			temp += "0";
		}
		temp += memory;
		rhs = temp;
	}
	else if(memory.length > rhs.length){
		largeststring = memory.length;
		var difference = memory.length - rhs.length;
		var temp = "";
		for(var i = 0; i < difference; i++){
			temp += "0";
		}
		temp += rhs;
		rhs = temp;
	}
	else{
		largeststring = memory.length;
	}
	var compliment = twosCompliment(rhs);
	var result = "";
	carry = 0;
	for(var i = largeststring - 1; i >= 0; i--){
		if(compliment[i] == 1 && 
				memory[i] == 1 && 
				carry == 0){
			result += "0";
			carry = 1;
		}
		else if(compliment[i] == 1 && 
				memory[i] == 1 &&
				carry == 1){
			result += "1";
			carry = 1;
		}
		else if(compliment[i] == 0 &&
				memory[i] == 0 && 
				carry == 1){
			result += "1";
			carry = 0;
		}
		else if(((compliment[i] == 1 && memory[i] == 0) ||
				(compliment[i] == 0 && memory[i] == 1)) &&
				carry == 1){
			result += "0";
			carry = 1;
		}
		else if(((compliment[i] == 1 && memory[i] == 0) ||
				(compliment[i] == 0 && memory[i] == 1)) &&
				carry == 0){
			result += "1";
			carry = 0;
		}
		else{
			result += "0";
			carry = 0;
		}
	}
	
//	result += carry;
	memory = reverse(result);
	document.getElementById("display").value = memory; 
};


function addmem(){
	var largeststring = 0;
	rhs = document.getElementById("display").value;
	// Check to see if rhs and lhs are the same length.
	// If not, pad the shorter side with zeros in front.
	if(memory.length < rhs.length){
		largeststring = rhs.length;
		var difference = rhs.length - memory.length;
		var temp = "";
		for(var i = 0; i < difference; i++){
			temp += "0";
		}
		temp += memory;
		memory = temp;
	}
	else if(memory.length > rhs.length){
		largeststring = memory.length;
		var difference = memory.length - rhs.length;
		var temp = "";
		for(var i = 0; i < difference; i++){
			temp += "0";
		}
		temp += rhs;
		rhs = temp;
	}
	else{
		largeststring = memory.length;
	}
	var ph = "";
	carry = 0;
	for(var i = largeststring - 1; i >= 0; i--){
		if(rhs[i] == 1 && 
			memory[i] == 1 && 
				carry == 0){
			ph += "0";
			carry = 1;
		}
		else if(rhs[i] == 1 && 
				memory[i] == 1 &&
				carry == 1){
			ph += "1";
			carry = 1;
		}
		else if(rhs[i] == 0 &&
				memory[i] == 0 && 
				carry == 1){
			ph += "1";
			carry = 0;
		}
		else if(((rhs[i] == 1 && memory[i] == 0) ||
				(rhs[i] == 0 && memory[i] == 1)) &&
				carry == 1){
			ph += "0";
			carry = 1;
		}
		else if(((rhs[i] == 1 && memory[i] == 0) ||
				(rhs[i] == 0 && memory[i] == 1)) &&
				carry == 0){
			ph += "1";
			carry = 0;
		}
		else{
			ph += "0";
			carry = 0;
		}
	}
	
	ph += carry;
	memory = reverse(ph);
//	updateDisplay(" M+ ");
	document.getElementById('display').value = memory; 
};

function wipescreen(){
	lhsbinaryvalue = "";
	rhsbinaryvalue = "";
	lhsdecimalvalue = 0;
	rhsdecimalvalue =0;
	document.getElementById("display").value = "";
};

function clearmem(){
	memory = 0;
	wipescreen();
//	updateDisplay(" MC ");
};

function storemem(){
	
	memory = document.getElementById("display").value; 
}

function equals(){	
	var token = document.getElementById("display").value.split(" ");
	var lhsbinaryvalue = token[0].trim();
	var symbol = token[1].trim();
	
	if(symbol != "~"){
		var rhsbinaryvalue = token[2].trim();
	}
	
	var result = "";
	switch(symbol){
	case "~":
		for(var i = 0; i < lhsbinaryvalue.length; i++){
			if(lhsbinaryvalue[i] == "1"){
				result += "0";
			}
			else{
				result += "1";
			}
		}
		break;
		
	case "+":
		var largeststring = 0;
		
		// Check to see if rhs and lhs are the same length.
		// If not, pad the shorter side with zeros in front.
		if(lhsbinaryvalue.length < rhsbinaryvalue.length){
			largeststring = rhsbinaryvalue.length;
			var difference = rhsbinaryvalue.length - lhsbinaryvalue.length;
			var temp = "";
			for(var i = 0; i < difference; i++){
				temp += "0";
			}
			temp += lhsbinaryvalue;
			lhsbinaryvalue = temp;
		}
		else if(lhsbinaryvalue.length > rhsbinaryvalue.length){
			largeststring = lhsbinaryvalue.length;
			var difference = lhsbinaryvalue.length - rhsbinaryvalue.length;
			var temp = "";
			for(var i = 0; i < difference; i++){
				temp += "0";
			}
			temp += rhsbinaryvalue;
			rhsbinaryvalue = temp;
		}
		else{
			largeststring = lhsbinaryvalue.length;
		}
		
		carry = 0;
		for(var i = largeststring - 1; i >= 0; i--){
			if(rhsbinaryvalue[i] == 1 && 
					lhsbinaryvalue[i] == 1 && 
					carry == 0){
				result += "0";
				carry = 1;
			}
			else if(rhsbinaryvalue[i] == 1 && 
					lhsbinaryvalue[i] == 1 &&
					carry == 1){
				result += "1";
				carry = 1;
			}
			else if(rhsbinaryvalue[i] == 0 &&
					lhsbinaryvalue[i] == 0 && 
					carry == 1){
				result += "1";
				carry = 0;
			}
			else if(((rhsbinaryvalue[i] == 1 && lhsbinaryvalue[i] == 0) ||
					(rhsbinaryvalue[i] == 0 && lhsbinaryvalue[i] == 1)) &&
					carry == 1){
				result += "0";
				carry = 1;
			}
			else if(((rhsbinaryvalue[i] == 1 && lhsbinaryvalue[i] == 0) ||
					(rhsbinaryvalue[i] == 0 && lhsbinaryvalue[i] == 1)) &&
					carry == 0){
				result += "1";
				carry = 0;
			}
			else{
				result += "0";
				carry = 0;
			}
		}
		
		result += carry;
		result = reverse(result);
		break;

	case "<<":
		var nshift = binarytodecimal(rhsbinaryvalue);
		result = lhsbinaryvalue.substring(nshift - 1);
		
		for(var i = 0; i < nshift; i++){
			result += 0;
		}
		break;
		
	case ">>":
		var nshift = binarytodecimal(rhsbinaryvalue);
		
		for(var i = 0; i < nshift; i++){
			result += 0;
		}
		result += lhsbinaryvalue.substring(0, rhsbinaryvalue.length - nshift - 1)
		
		break;
		
	case "-":
		var largeststring = 0;
		
		// Check to see if rhs and lhs are the same length.
		// If not, pad the shorter side with zeros in front.
		if(lhsbinaryvalue.length < rhsbinaryvalue.length){
			largeststring = rhsbinaryvalue.length;
			var difference = rhsbinaryvalue.length - lhsbinaryvalue.length;
			var temp = "";
			for(var i = 0; i < difference; i++){
				temp += "0";
			}
			temp += lhsbinaryvalue;
			lhsbinaryvalue = temp;
		}
		else if(lhsbinaryvalue.length > rhsbinaryvalue.length){
			largeststring = lhsbinaryvalue.length;
			var difference = lhsbinaryvalue.length - rhsbinaryvalue.length;
			var temp = "";
			for(var i = 0; i < difference; i++){
				temp += "0";
			}
			temp += rhsbinaryvalue;
			rhsbinaryvalue = temp;
		}
		else{
			largeststring = lhsbinaryvalue.length;
		}
		var compliment = twosCompliment(rhsbinaryvalue);
		carry = 0;
		for(var i = largeststring - 1; i >= 0; i--){
			if(compliment[i] == 1 && 
					lhsbinaryvalue[i] == 1 && 
					carry == 0){
				result += "0";
				carry = 1;
			}
			else if(compliment[i] == 1 && 
					lhsbinaryvalue[i] == 1 &&
					carry == 1){
				result += "1";
				carry = 1;
			}
			else if(compliment[i] == 0 &&
					lhsbinaryvalue[i] == 0 && 
					carry == 1){
				result += "1";
				carry = 0;
			}
			else if(((compliment[i] == 1 && lhsbinaryvalue[i] == 0) ||
					(compliment[i] == 0 && lhsbinaryvalue[i] == 1)) &&
					carry == 1){
				result += "0";
				carry = 1;
			}
			else if(((compliment[i] == 1 && lhsbinaryvalue[i] == 0) ||
					(compliment[i] == 0 && lhsbinaryvalue[i] == 1)) &&
					carry == 0){
				result += "1";
				carry = 0;
			}
			else{
				result += "0";
				carry = 0;
			}
		}
		
//		result += carry;
		result = reverse(result);
		break;
		
	case "&":
		var largeststring = 0;
		// Check to see if rhs and lhs are the same length.
		// If not, pad the shorter side with zeros in front.
		if(lhsbinaryvalue.length < rhsbinaryvalue.length){
			largeststring = rhsbinaryvalue.length;
			var difference = rhsbinaryvalue.length - lhsbinaryvalue.length;
			var temp = "";
			for(var i = 0; i < difference; i++){
				temp += "0";
			}
			temp += lhsbinaryvalue;
			lhsbinaryvalue = temp;
		}
		else if(lhsbinaryvalue.length > rhsbinaryvalue.length){
			largeststring = lhsbinaryvalue.length;
			var difference = lhsbinaryvalue.length - rhsbinaryvalue.length;
			var temp = "";
			for(var i = 0; i < difference; i++){
				temp += "0";
			}
			temp += rhsbinaryvalue;
			rhsbinaryvalue = temp;
		}
		else{
			largeststring = lhsbinaryvalue.length;
		}
		
		for(var i = 0; i < largeststring; i++){
			if(rhsbinaryvalue[i] == 1 && 
			   lhsbinaryvalue[i] == 1){
				result += "1";
			}
			else {
				result += "0";
			}
		}
		break;
		
	case "|":
		var largeststring = 0;
		// Check to see if rhs and lhs are the same length.
		// If not, pad the shorter side with zeros in front.
		if(lhsbinaryvalue.length < rhsbinaryvalue.length){
			largeststring = rhsbinaryvalue.length;
			var difference = rhsbinaryvalue.length - lhsbinaryvalue.length;
			var temp = "";
			for(var i = 0; i < difference; i++){
				temp += "0";
			}
			temp += lhsbinaryvalue;
			lhsbinaryvalue = temp;
		}
		else if(lhsbinaryvalue.length > rhsbinaryvalue.length){
			largeststring = lhsbinaryvalue.length;
			var difference = lhsbinaryvalue.length - rhsbinaryvalue.length;
			var temp = "";
			for(var i = 0; i < difference; i++){
				temp += "0";
			}
			temp += rhsbinaryvalue;
			rhsbinaryvalue = temp;
		}
		else{
			largeststring = lhsbinaryvalue.length;
		}
		
		for(var i = 0; i < largeststring; i++){
	
			if(rhsbinaryvalue[i] == 0 && 
			   lhsbinaryvalue[i] == 0){
				result += "0";
			}
			else {
				result += "1";
			}
		}
		break;
		
	case "*":
		var partial = [""];
		for(var i = rhsbinaryvalue.length-1; i >= 0; i--){
			if(rhsbinaryvalue[i] == "1"){
				partial[rhsbinaryvalue.length-1-i] = lhsbinaryvalue;
			}
			else{
				partial[rhsbinaryvalue.length-1-i] = "0";
			}
			//Adding trailing zeros.
			for(var j = 0; j < rhsbinaryvalue.length-1-i; j++){
				partial[rhsbinaryvalue.length-1-i] += "0";
			}
		}
		//Add the partial products
		var product = partial[0];
			if(partial.length > 1){
				for(var k = 1; k < partial.length; k++){
					var largeststring = 0;					
					// Check to see if rhs and lhs are the same length.
					// If not, pad the shorter side with zeros in front.
					if(product.length > partial[k].length){
						largeststring = product.length;
						var difference = product.length - partial[k].length;
						var temp = "";
						for(var i = 0; i < difference; i++){
							temp += "0";
						}
						temp += partial[k];
						partial[k] = temp;
					}
					else if(product.length < partial[k].length){
						largeststring = partial[k].length;
						var difference = partial[k].length - product.length;
						var temp = "";
						for(var i = 0; i < difference; i++){
							temp += "0";
						}
						temp += product;
						product = temp;
					}
					else{
						largeststring = product.length;
					}
					carry = 0;
					var ph = "";
					for(var i = largeststring - 1; i >= 0; i--){
						if(partial[k][i] == 1 && 
								product[i] == 1 && 
								carry == 0){
							ph += "0";
							carry = 1;
						}
						else if(partial[k][i] == 1 && 
								product[i] == 1 &&
								carry == 1){
							ph += "1";
							carry = 1;
						}
						else if(partial[k][i] == 0 &&
								product[i] == 0 && 
								carry == 1){
							ph += "1";
							carry = 0;
						}
						else if(((partial[k][i] == 1 && product[i] == 0) ||
								(partial[k][i] == 0 && product[i] == 1)) &&
								carry == 1){
							ph += "0";
							carry = 1;
						}
						else if(((partial[k][i] == 1 && product[i] == 0) ||
								(partial[k][i] == 0 && product[i] == 1)) &&
								carry == 0){
							ph += "1";
							carry = 0;
						}
						else{
							ph += "0";
							carry = 0;
						}
					}
					ph += carry;
					product = reverse(ph);
				}
			}
			result = product;
		break;
		
	case "/":	
		var lhsdecimal = binarytodecimal(lhsbinaryvalue);
		var rhsdecimal = binarytodecimal(rhsbinaryvalue);
		var dividen = lhsdecimal / rhsdecimal;
		
		result = decimaltobinary(dividen);
		break;
		
	default:
		alert("Not a valid input.");
		break;
	}
	
	document.getElementById("display").value = "";
	updateDisplay(result);
};
